from turtle import circle
from point import Point
from innercircle import InnerCircle
from outercircle import OuterCircle
from square import Square

p = Point(0,0)
q = Point(4,4)
sq = Square(p,q)
print(sq.calculate())

circle_inner = InnerCircle(p,q)
circle_outer = OuterCircle(p,q)

print(circle_inner.calculate() , circle_outer.calculate())
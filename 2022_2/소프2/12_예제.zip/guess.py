class Guess:

    def __init__(self, word):
        pass


    def display(self):
        pass


    def guess(self, character):
        pass
